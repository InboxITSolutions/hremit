	<meta charset="utf-8">
	<meta name="viewport"    content="width=device-width, initial-scale=1.0">
	<meta name="description" content="Hulas Remittance">
	<meta name="author"      content="Govinda Aryal">
	<meta name="format-detection" content="telephone=no">
	<!--fav icon -->
	<link rel="shortcut icon" type="image/png" href="assets/front/images/favicon.ico"/><!-- fav icon -->
	<link rel="stylesheet" href="{{url('assets/bootstrap/dist/css/bootstrap.min.css')}}"><!-- Bootstrap css -->
	<link rel="stylesheet" href="{{url('assets/fa/css/font-awesome.min.css')}}"><!-- Font Awesome Css -->
	<link rel="stylesheet" href="{{url('assets/front/css/main.css')}}"><!-- Front-End CSS -->
	<link rel="stylesheet" href="{{url('assets/front/css/media.css')}}"><!-- Front-End CSS -->
	<script type="text/javascript" src="{{url('assets/front/js/stickynav.js')}}"></script>
	<link href="{{url('assets/front/css/jquery.fancybox.css')}}" rel="stylesheet">
	<link href="{{url('assets/front/css/jquery.media.css')}}" rel="stylesheet">