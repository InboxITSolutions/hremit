

						<?php 
						$zoneId = 1;
						echo $zoneId; 
						?>