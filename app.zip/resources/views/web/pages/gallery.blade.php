@extends('web.layouts.master')
@section('title')
Gallery
@endsection
@section('content')
<section id="about-title">
	<div class="container">
		<div class="col-xs-12 col-sm-4 col-md-12 col-lg-12 title">
			<h1>Gallery</h1>
		</div>
	</div>
</section>
<section id="gallery">
<<<<<<< HEAD
	<div class="col-xs-12 col-sm-3 col-md-12 col-lg-12 gallery-div">
		<div class="col-xs-12 col-sm-3 col-md-3 gallery-image ">
=======
	<div class="col-xs-12 col-sm-4 col-md-12 col-lg-12 gallery-div">
		<div class="col-xs-12 col-sm-4 col-md-4 gallery-image ">
>>>>>>> a02be301d35b8528f79a85647ef65d1ae806da76
			<div class="col-xs-12 col-sm-4 col-md-12">
				<a class="single_image" rel="gallery" href="{{url('assets/front/images/gallery/1.png')}}"><img src="{{url('assets/front/images/gallery/1.png')}}" alt="" class="img-responsive"/></a>
			</div>
		</div>
<<<<<<< HEAD
		<div class="col-xs-12 col-sm-3 col-md-3 gallery-image ">
=======
		<div class="col-xs-12 col-sm-4 col-md-4 gallery-image ">
>>>>>>> a02be301d35b8528f79a85647ef65d1ae806da76
			<div class="col-xs-12 col-sm-4 col-md-12">
				<a class="single_image" rel="gallery" href="{{url('assets/front/images/gallery/2.png')}}"><img src="{{url('assets/front/images/gallery/2.png')}}" alt="" class="img-responsive"/></a>
			</div>
		</div>
<<<<<<< HEAD
		<div class="col-xs-12 col-sm-3 col-md-3 gallery-image ">
=======
		<div class="col-xs-12 col-sm-4 col-md-4 gallery-image ">
>>>>>>> a02be301d35b8528f79a85647ef65d1ae806da76
			<div class="col-xs-12 col-sm-4 col-md-12">
				<a class="single_image" rel="gallery" href="{{url('assets/front/images/gallery/3.png')}}"><img src="{{url('assets/front/images/gallery/3.png')}}" alt="" class="img-responsive"/></a>
			</div>
		</div>
<<<<<<< HEAD
		<div class="col-xs-12 col-sm-3 col-md-3 gallery-image ">
=======
		<div class="col-xs-12 col-sm-4 col-md-4 gallery-image ">
>>>>>>> a02be301d35b8528f79a85647ef65d1ae806da76
			<div class="col-xs-12 col-sm-4 col-md-12">
				<a class="single_image" rel="gallery" href="{{url('assets/front/images/gallery/4.png')}}"><img src="{{url('assets/front/images/gallery/4.png')}}" alt="" class="img-responsive"/></a>
			</div>
		</div>
<<<<<<< HEAD
		<div class="col-xs-12 col-sm-3 col-md-3 gallery-image ">
=======
		<div class="col-xs-12 col-sm-4 col-md-4 gallery-image ">
>>>>>>> a02be301d35b8528f79a85647ef65d1ae806da76
			<div class="col-xs-12 col-sm-4 col-md-12">
				<a class="single_image" rel="gallery" href="{{url('assets/front/images/gallery/5.png')}}"><img src="{{url('assets/front/images/gallery/5.png')}}" alt="" class="img-responsive"/></a>
			</div>
		</div>
<<<<<<< HEAD
		<div class="col-xs-12 col-sm-3 col-md-3 gallery-image ">
=======
		<div class="col-xs-12 col-sm-4 col-md-4 gallery-image ">
>>>>>>> a02be301d35b8528f79a85647ef65d1ae806da76
			<div class="col-xs-12 col-sm-4 col-md-12">
				<a class="single_image" rel="gallery" href="{{url('assets/front/images/gallery/6.png')}}"><img src="{{url('assets/front/images/gallery/6.png')}}" alt="" class="img-responsive"/></a>
			</div>
		</div>
<<<<<<< HEAD
		<div class="col-xs-12 col-sm-3 col-md-3 gallery-image ">
=======
		<div class="col-xs-12 col-sm-4 col-md-4 gallery-image ">
>>>>>>> a02be301d35b8528f79a85647ef65d1ae806da76
			<div class="col-xs-12 col-sm-4 col-md-12">
				<a class="single_image" rel="gallery" href="{{url('assets/front/images/gallery/7.png')}}"><img src="{{url('assets/front/images/gallery/7.png')}}" alt="" class="img-responsive"/></a>
			</div>
		</div>
<<<<<<< HEAD
		<div class="col-xs-12 col-sm-3 col-md-3 gallery-image ">
=======
		<div class="col-xs-12 col-sm-4 col-md-4 gallery-image ">
>>>>>>> a02be301d35b8528f79a85647ef65d1ae806da76
			<div class="col-xs-12 col-sm-4 col-md-12">
				<a class="single_image" rel="gallery" href="{{url('assets/front/images/gallery/8.png')}}"><img src="{{url('assets/front/images/gallery/8.png')}}" alt="" class="img-responsive"/></a>
			</div>
		</div> 
<<<<<<< HEAD
		<div class="col-xs-12 col-sm-3 col-md-3 gallery-image ">
=======
		<div class="col-xs-12 col-sm-4 col-md-4 gallery-image ">
>>>>>>> a02be301d35b8528f79a85647ef65d1ae806da76
			<div class="col-xs-12 col-sm-4 col-md-12">
				<a class="single_image" rel="gallery" href="{{url('assets/front/images/gallery/1.png')}}"><img src="{{url('assets/front/images/gallery/1.png')}}" alt="" class="img-responsive"/></a>
			</div>
		</div>
    </div>	
</section>
        
        
@endsection
